{
"question":"<img src='Symbols/Symbol_4.png'height=100px;width=150px;>",
"choice1":"Right Curve",
"choice2":"Combined Curves Ahead",
"choice3":"Winding Road Ahead",
"choice4":"Overtake",
"correct":3
},
{
"question":"<img src='Symbols/Symbol_5.png'height=100px;width=150px;>",
"choice1":"By Pixels",
"choice2":"By Percentage",
"choice3":"By auto",
"choice4":"Any one of these",
"correct":3
},
{
"question":"<img src='Symbols/Symbol_6.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_7.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_8.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_9.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_10.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_11.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_12.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_13.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_14.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_15.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_16.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_17.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_18.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_19.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_20.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_21.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_22.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_23.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_24.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_25.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_26.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_27.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_28.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_29.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_30.png'height=100px;width=150px;>",
"choice1":"Hello World",
"choice2":"Notice: Undefined.",
"choice3":"Does not display anything",
"choice4":"None of the above",
"correct":1
}