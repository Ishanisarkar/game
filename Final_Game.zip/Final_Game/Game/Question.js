var Questions={"question":[
{
"question":"<img src='Symbols/Symbol_1.png' height=100px;width=150px;>",
"choice1":"Road Narrows Both Sides Ahead",
"choice2":"Bridge Ahead",
"choice3":"Narrow Bridge",
"choice4":"Left And Right Road Ends",
"correct":1
},
{
"question":"<img src='Symbols/Symbol_2.png'height=100px;width=150px;>",
"choice1":"Left Lane Ends Here",
"choice2":"Right Lane Ends Here",
"choice3":"Road Narrows Both Sides Ahead",
"choice4":"Narrow Right Lane",
"correct":2
},
{
"question":"<img src='Symbols/Symbol_3.png'height=100px;width=150px;>",
"choice1":"Right Lane Ends Here",
"choice2":"Bridge Ends Here",
"choice3":"Left Lane Ends Here",
"choice4":"None of the above",
"correct":3
},

]};
